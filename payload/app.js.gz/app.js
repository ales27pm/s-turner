(() => {
  'use strict';

  const models = [
    {
      id: 'athenes',
      name: 'Athènes',
      type: 'Chalet',
      style: 'Contemporain',
      bedrooms: 1,
      bathrooms: 1,
      floors: 1,
      garage: false,
      area: 576,
      description: 'Un chalet compact pensé pour rapprocher l’aire de vie du paysage, avec une généreuse fenestration et un plafond cathédrale.',
      features: ['Grande fenestration en façade', 'Aire de vie avec plafond cathédrale', 'Format compact et économique'],
      remoteImage: 'https://maisonsturner.ca/app/uploads/2024/02/athenes-1-1015x762.jpg',
      localImage: './public/images/athenes-generated.avif'
    },
    {
      id: 'prague',
      name: 'Prague',
      type: 'Plain-pied',
      style: 'Contemporain',
      bedrooms: 2,
      bathrooms: 1,
      floors: 1,
      garage: false,
      area: 1034,
      description: 'Un plain-pied lumineux où la cuisine, la salle à manger et le séjour forment un espace simple à habiter au quotidien.',
      features: ['Cuisine avec îlot généreux', 'Deux chambres avec rangement', 'Plan optimisé pour chaque pièce'],
      remoteImage: 'https://maisonsturner.ca/app/uploads/2024/03/prague-1-1015x762.jpg',
      localImage: './public/images/prague-generated.avif'
    },
    {
      id: 'oslo',
      name: 'Oslo',
      type: 'Chalet',
      style: 'Contemporain',
      bedrooms: 2,
      bathrooms: 1,
      floors: 1,
      garage: false,
      area: 1067,
      description: 'Une silhouette monopente, une aire ouverte et beaucoup de lumière naturelle pour une relation directe avec le terrain.',
      features: ['Toiture monopente', 'Aire ouverte spacieuse', 'Option rez-de-jardin disponible'],
      remoteImage: 'https://maisonsturner.ca/app/uploads/2024/02/oslo-1-1015x762.jpg',
      localImage: './public/images/oslo-generated.avif'
    },
    {
      id: 'portofino',
      name: 'Portofino',
      type: 'Plain-pied',
      style: 'Contemporain',
      bedrooms: 2,
      bathrooms: 1,
      floors: 1,
      garage: false,
      area: 1222,
      description: 'Un plan rassembleur articulé autour d’un grand espace ouvert, d’une cuisine généreuse et d’un escalier central distinctif.',
      features: ['Cuisine à fort potentiel de rangement', 'Grande chambre principale', 'Circulation centrale conviviale'],
      remoteImage: 'https://maisonsturner.ca/app/uploads/2024/02/portofino-1-1015x762.jpg',
      localImage: './public/images/portofino-concept.jpg'
    },
    {
      id: 'turenne',
      name: 'Turenne',
      type: 'Plain-pied',
      style: 'Contemporain',
      bedrooms: 2,
      bathrooms: 1,
      floors: 1,
      garage: true,
      area: 1400,
      description: 'Un plain-pied avec garage où l’aire de vie s’ouvre vers l’arrière, complété par une grande entrée et un espace bureau.',
      features: ['Garage chauffé avec accès direct', 'Espace bureau', 'Aire de vie orientée vers la cour'],
      remoteImage: 'https://maisonsturner.ca/app/uploads/2024/02/turenne-1-1015x762.jpg',
      localImage: './public/images/turenne-concept.jpg'
    },
    {
      id: 'liverpool',
      name: 'Liverpool',
      type: 'Plain-pied',
      style: 'Classique',
      bedrooms: 2,
      bathrooms: 1,
      floors: 1,
      garage: false,
      area: 1075,
      description: 'Une interprétation farmhouse chaleureuse, pensée pour la vie familiale, avec une aire commune à l’arrière et une belle fenestration.',
      features: ['Expression farmhouse', 'Salle de bain optimisée', 'Aire de vie intime à l’arrière'],
      remoteImage: 'https://maisonsturner.ca/app/uploads/2024/02/liverpool-1-1015x762.jpg',
      localImage: './public/images/liverpool-concept.jpg'
    }
  ];

  const processSteps = [
    {
      label: 'Étape 01',
      title: 'Comprendre le terrain, les besoins et la capacité budgétaire.',
      copy: 'Le bon modèle dépend du lot, des services disponibles, des règlements municipaux, du relief et des travaux que vous souhaitez garder sous votre responsabilité.',
      checks: ['Rassembler les informations du terrain', 'Définir chambres, étages et sous-sol', 'Identifier les travaux faits par le client', 'Sélectionner un plan de départ']
    },
    {
      label: 'Étape 02',
      title: 'Personnaliser le plan avant de verrouiller les choix.',
      copy: 'L’équipe ajuste l’organisation, les matériaux et les couleurs, puis prépare un plan final qui devient la référence commune du projet.',
      checks: ['Valider les modifications au plan', 'Choisir matériaux et couleurs', 'Clarifier les inclusions', 'Recevoir le plan final']
    },
    {
      label: 'Étape 03',
      title: 'Signer, planifier et fabriquer avec des jalons visibles.',
      copy: 'La signature enclenche la commande, l’échéancier de production et la coordination du chantier. Une visite en usine permet de voir les modules prendre forme.',
      checks: ['Signer le contrat officiel', 'Confirmer l’échéancier', 'Coordonner les intervenants', 'Visiter la maison en usine']
    },
    {
      label: 'Étape 04',
      title: 'Assembler, inspecter et rester présent après la livraison.',
      copy: 'Les équipes finalisent le raccord de menuiserie, inspectent le résultat avec le client et assurent un lien clair avec le service après-vente.',
      checks: ['Livraison et assemblage des modules', 'Finition du raccord de menuiserie', 'Inspection de fin de mandat', 'Remise des clés et service après-vente']
    }
  ];

  const faqItems = [
    {
      question: 'Livrez-vous les maisons partout au Québec?',
      answer: 'Oui. L’entreprise indique livrer ses projets partout au Québec. La faisabilité et les coûts de transport demeurent à confirmer selon l’emplacement et l’accès au terrain.'
    },
    {
      question: 'Puis-je modifier un plan existant?',
      answer: 'Oui, plusieurs modifications peuvent être étudiées avec un conseiller. La structure du modèle, le transport des modules et les contraintes réglementaires déterminent ce qui est réaliste.'
    },
    {
      question: 'Puis-je prendre certains travaux en charge?',
      answer: 'Oui. Le projet peut être réparti entre Turner, des sous-traitants et le client. La matrice des inclusions du prototype sert précisément à rendre cette responsabilité visible.'
    },
    {
      question: 'Excavation et fondation peuvent-elles être coordonnées?',
      answer: 'Oui. Ces travaux peuvent être pris en charge dans le projet ou confiés à des intervenants choisis par le client, selon l’entente préparée avec le conseiller.'
    },
    {
      question: 'Qu’est-ce qu’un raccord de menuiserie?',
      answer: 'C’est le travail effectué au chantier pour relier les sections de la maison et terminer les zones de jonction : toiture, isolation, revêtement et murs intérieurs selon le devis.'
    },
    {
      question: 'Peut-on visiter des maisons modèles?',
      answer: 'Oui. Plusieurs modèles sont annoncés comme visitables aux installations de Trois-Rivières. Il est préférable de confirmer le modèle et l’heure avant le déplacement.'
    }
  ];

  const inclusionGroups = [
    {
      title: 'Inclus par Turner',
      intro: 'Éléments couramment intégrés au module ou au mandat de base, selon le plan et le devis.',
      items: ['Plan complet', 'Garantie GCR', 'Transport des modules et grue', 'Raccord de menuiserie', 'Portes extérieures et fenêtres', 'Plomberie et électricité dans les murs', 'Armoires et comptoirs installés', 'Appareils sanitaires de base', 'Isolation supérieure aux normes applicables']
    },
    {
      title: 'Options à coordonner',
      intro: 'Travaux qui peuvent être ajoutés au mandat ou gérés séparément.',
      items: ['Excavation', 'Fondation', 'Raccordements électriques et plomberie', 'Maçonnerie et joints', 'Peinture et couvre-plancher', 'Finition du sous-sol', 'Perron, patio et rampes']
    },
    {
      title: 'Par le client',
      intro: 'Éléments identifiés publiquement comme étant normalement à la charge du propriétaire.',
      items: ['Gouttières', 'Aménagement paysager', 'Crépi', 'Luminaires décoratifs']
    }
  ];

  const state = {
    filters: { type: '', style: '', bedrooms: '', garage: '', area: '' },
    compared: new Set(),
    currentProcessStep: 0
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const currency = new Intl.NumberFormat('fr-CA', { style: 'currency', currency: 'CAD', maximumFractionDigits: 0 });
  const number = new Intl.NumberFormat('fr-CA');

  function escapeHTML(value) {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function imageMarkup(model, className = '') {
    const source = escapeHTML(model.localImage);
    return `<img class="${escapeHTML(className)}" src="${source}" alt="Visualisation architecturale associée au modèle ${escapeHTML(model.name)}" loading="eager" decoding="async" />`;
  }

  function showToast(message) {
    const toast = $('#toast');
    toast.textContent = message;
    toast.classList.add('is-visible');
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove('is-visible'), 3000);
  }

  function getFilteredModels() {
    return models.filter((model) => {
      if (state.filters.type && model.type !== state.filters.type) return false;
      if (state.filters.style && model.style !== state.filters.style) return false;
      if (state.filters.bedrooms && model.bedrooms !== Number(state.filters.bedrooms)) return false;
      if (state.filters.garage && model.garage !== (state.filters.garage === 'true')) return false;
      if (state.filters.area === 'compact' && model.area >= 900) return false;
      if (state.filters.area === 'medium' && (model.area < 900 || model.area >= 1200)) return false;
      if (state.filters.area === 'large' && model.area < 1200) return false;
      return true;
    });
  }

  function buildActiveFilterCopy(filtered) {
    const active = [];
    if (state.filters.type) active.push(state.filters.type);
    if (state.filters.style) active.push(state.filters.style);
    if (state.filters.bedrooms) active.push(`${state.filters.bedrooms} chambre${state.filters.bedrooms === '1' ? '' : 's'}`);
    if (state.filters.garage) active.push(state.filters.garage === 'true' ? 'avec garage' : 'sans garage');
    if (state.filters.area === 'compact') active.push('moins de 900 pi²');
    if (state.filters.area === 'medium') active.push('900 à 1 199 pi²');
    if (state.filters.area === 'large') active.push('1 200 pi² et plus');
    return active.length ? `${active.join(' · ')} — ${filtered.length} résultat${filtered.length > 1 ? 's' : ''}` : 'Tous les modèles du prototype';
  }

  function renderModels() {
    const grid = $('#model-grid');
    const empty = $('#empty-state');
    const filtered = getFilteredModels();
    $('#result-count').textContent = `${filtered.length} modèle${filtered.length > 1 ? 's' : ''}`;
    $('#active-filter-copy').textContent = buildActiveFilterCopy(filtered);

    if (!filtered.length) {
      grid.innerHTML = '';
      empty.hidden = false;
      return;
    }

    empty.hidden = true;
    grid.innerHTML = filtered.map((model, index) => `
      <article class="model-card" style="animation-delay:${index * 45}ms">
        <div class="model-image">
          ${imageMarkup(model)}
          <span class="model-type">${escapeHTML(model.type)} · ${escapeHTML(model.style)}</span>
          <button class="compare-toggle" type="button" aria-pressed="${state.compared.has(model.id)}" data-compare-id="${model.id}">
            ${state.compared.has(model.id) ? 'Sélectionné' : 'Comparer'}
          </button>
        </div>
        <div class="model-body">
          <div class="model-title-row">
            <h3>${escapeHTML(model.name)}</h3>
            <span>${number.format(model.area)} pi²</span>
          </div>
          <p class="model-description">${escapeHTML(model.description)}</p>
          <div class="model-specs" aria-label="Spécifications du modèle ${escapeHTML(model.name)}">
            <div><strong>${model.bedrooms}</strong><span>Chambre${model.bedrooms > 1 ? 's' : ''}</span></div>
            <div><strong>${model.bathrooms}</strong><span>Salle de bain</span></div>
            <div><strong>${model.floors}</strong><span>Étage</span></div>
            <div><strong>${model.garage ? 'Oui' : 'Non'}</strong><span>Garage</span></div>
          </div>
          <div class="model-actions">
            <button class="details-button" type="button" data-model-id="${model.id}">Voir le modèle →</button>
            <button class="quote-button" type="button" data-quote-model="${model.id}">Préparer une demande</button>
          </div>
        </div>
      </article>
    `).join('');
  }

  function resetFilters({ scroll = false } = {}) {
    state.filters = { type: '', style: '', bedrooms: '', garage: '', area: '' };
    $('#finder-form').reset();
    renderModels();
    if (scroll) $('#modeles').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function syncFiltersFromForm() {
    state.filters = {
      type: $('#filter-type').value,
      style: $('#filter-style').value,
      bedrooms: $('#filter-bedrooms').value,
      garage: $('#filter-garage').value,
      area: $('#filter-area').value
    };
    renderModels();
  }

  function setCollectionFilter(value) {
    resetFilters();
    if (value === 'garage') {
      state.filters.garage = 'true';
      $('#filter-garage').value = 'true';
    } else {
      state.filters.type = value;
      $('#filter-type').value = value;
    }
    renderModels();
    $('.catalog-toolbar').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function openDialog(dialog) {
    if (!dialog) return;
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
    document.body.classList.add('dialog-open');
  }

  function closeDialog(dialog) {
    if (!dialog) return;
    if (typeof dialog.close === 'function') dialog.close();
    else dialog.removeAttribute('open');
    if (!$('dialog[open]')) document.body.classList.remove('dialog-open');
  }

  function openModelDialog(modelId) {
    const model = models.find((item) => item.id === modelId);
    if (!model) return;
    const content = $('#model-dialog-content');
    content.innerHTML = `
      <div class="model-dialog-hero">
        ${imageMarkup(model)}
        <div class="model-dialog-heading">
          <span>${escapeHTML(model.type)} · ${escapeHTML(model.style)}</span>
          <h2 id="model-dialog-title">${escapeHTML(model.name)}</h2>
        </div>
      </div>
      <div class="model-dialog-body">
        <div>
          <p>${escapeHTML(model.description)}</p>
          <ul class="dialog-features">${model.features.map((feature) => `<li>${escapeHTML(feature)}</li>`).join('')}</ul>
        </div>
        <div>
          <div class="dialog-spec-grid">
            <div><strong>${model.bedrooms}</strong><span>Chambre${model.bedrooms > 1 ? 's' : ''}</span></div>
            <div><strong>${model.bathrooms}</strong><span>Salle de bain</span></div>
            <div><strong>${model.floors}</strong><span>Étage</span></div>
            <div><strong>${model.garage ? 'Oui' : 'Non'}</strong><span>Garage</span></div>
            <div><strong>${number.format(model.area)}</strong><span>Superficie en pi²</span></div>
            <div><strong>${escapeHTML(model.style)}</strong><span>Style</span></div>
          </div>
          <div class="dialog-actions">
            <button class="button button-primary" type="button" data-dialog-quote="${model.id}">Préparer une demande</button>
            <a class="button button-secondary" href="https://maisonsturner.ca/modeles/${model.id}" target="_blank" rel="noreferrer">Voir la fiche actuelle</a>
          </div>
        </div>
      </div>
    `;
    openDialog($('#model-dialog'));
  }

  function toggleCompare(modelId) {
    if (state.compared.has(modelId)) {
      state.compared.delete(modelId);
    } else if (state.compared.size >= 3) {
      showToast('Vous pouvez comparer jusqu’à trois modèles.');
      return;
    } else {
      state.compared.add(modelId);
    }
    renderModels();
    renderCompareTray();
  }

  function renderCompareTray() {
    const tray = $('#compare-tray');
    const selected = models.filter((model) => state.compared.has(model.id));
    tray.hidden = selected.length === 0;
    $('#compare-summary').textContent = `${selected.length} modèle${selected.length > 1 ? 's' : ''} sélectionné${selected.length > 1 ? 's' : ''}`;
    $('#compare-chips').innerHTML = selected.map((model) => `
      <span class="compare-chip">${escapeHTML(model.name)} <button type="button" data-remove-compare="${model.id}" aria-label="Retirer ${escapeHTML(model.name)}">×</button></span>
    `).join('');
    const compareButton = $('#open-compare');
    compareButton.disabled = selected.length < 2;
    compareButton.title = selected.length < 2 ? 'Sélectionnez au moins deux modèles' : '';
  }

  function openCompareDialog() {
    const selected = models.filter((model) => state.compared.has(model.id));
    if (selected.length < 2) {
      showToast('Sélectionnez au moins deux modèles.');
      return;
    }
    const rows = [
      ['Type', (m) => m.type],
      ['Style', (m) => m.style],
      ['Superficie', (m) => `${number.format(m.area)} pi²`],
      ['Chambres', (m) => m.bedrooms],
      ['Salles de bain', (m) => m.bathrooms],
      ['Garage', (m) => m.garage ? 'Oui' : 'Non'],
      ['Points forts', (m) => m.features.join(' · ')]
    ];
    $('#compare-dialog-content').innerHTML = `
      <div class="compare-dialog-content">
        <h2 id="compare-dialog-title">Comparer sans se perdre.</h2>
        <p>La comparaison porte sur les données publiques utilisées dans ce prototype. Un conseiller doit confirmer les options et modifications possibles.</p>
        <div class="compare-table-wrap">
          <table class="compare-table">
            <thead><tr><th>Critère</th>${selected.map((model) => `<th>${imageMarkup(model, 'compare-image')}${escapeHTML(model.name)}</th>`).join('')}</tr></thead>
            <tbody>${rows.map(([label, getter]) => `<tr><th>${escapeHTML(label)}</th>${selected.map((model) => `<td>${escapeHTML(getter(model))}</td>`).join('')}</tr>`).join('')}</tbody>
          </table>
        </div>
      </div>
    `;
    openDialog($('#compare-dialog'));
  }

  function renderProcessStep(index) {
    const step = processSteps[index];
    state.currentProcessStep = index;
    $$('.process-tabs button').forEach((button, buttonIndex) => {
      button.setAttribute('aria-selected', String(buttonIndex === index));
      button.tabIndex = buttonIndex === index ? 0 : -1;
    });
    $('#process-detail').innerHTML = `
      <span class="process-number">${escapeHTML(step.label)}</span>
      <h3>${escapeHTML(step.title)}</h3>
      <p>${escapeHTML(step.copy)}</p>
      <ul class="process-checks">${step.checks.map((item) => `<li>${escapeHTML(item)}</li>`).join('')}</ul>
    `;
  }

  function renderFaq() {
    $('#faq-list').innerHTML = faqItems.map((item, index) => `
      <article class="faq-item">
        <button class="faq-question" type="button" aria-expanded="${index === 0}" aria-controls="faq-answer-${index}" data-faq-index="${index}">
          <span class="faq-number">${String(index + 1).padStart(2, '0')}</span>
          <strong>${escapeHTML(item.question)}</strong>
          <span class="faq-plus" aria-hidden="true">+</span>
        </button>
        <div class="faq-answer" id="faq-answer-${index}" ${index === 0 ? '' : 'hidden'}>${escapeHTML(item.answer)}</div>
      </article>
    `).join('');
  }

  function toggleFaq(index) {
    const button = $(`[data-faq-index="${index}"]`);
    const panel = $(`#faq-answer-${index}`);
    const willOpen = button.getAttribute('aria-expanded') !== 'true';
    button.setAttribute('aria-expanded', String(willOpen));
    panel.hidden = !willOpen;
  }

  function renderInclusions() {
    $('#inclusion-columns').innerHTML = inclusionGroups.map((group) => `
      <article class="inclusion-column">
        <h3>${escapeHTML(group.title)}</h3>
        <p>${escapeHTML(group.intro)}</p>
        <ul>${group.items.map((item) => `<li>${escapeHTML(item)}</li>`).join('')}</ul>
      </article>
    `).join('');
  }

  function populateModelSelects() {
    const options = `<option value="">À déterminer</option>${models.map((model) => `<option value="${model.id}">${escapeHTML(model.name)} — ${number.format(model.area)} pi²</option>`).join('')}`;
    $('#budget-model').innerHTML = options;
    $('#contact-model').innerHTML = options;
  }

  function valueOf(id) {
    return Math.max(0, Number($(id).value) || 0);
  }

  function updateBudget() {
    const target = valueOf('#budget-target');
    const lineItems = ['#budget-house', '#budget-land', '#budget-foundation', '#budget-site', '#budget-options', '#budget-other'];
    const subtotal = lineItems.reduce((sum, id) => sum + valueOf(id), 0);
    const contingencyRate = valueOf('#budget-contingency');
    const contingency = subtotal * (contingencyRate / 100);
    const total = subtotal + contingency;
    const gap = target - total;

    $('#contingency-label').textContent = `${contingencyRate} %`;
    $('#budget-subtotal').textContent = currency.format(subtotal);
    $('#budget-contingency-total').textContent = currency.format(contingency);
    $('#budget-total').textContent = currency.format(total);
    $('#budget-gap').textContent = currency.format(gap);
    const gapWrap = $('#budget-gap-wrap');
    gapWrap.classList.toggle('positive', gap >= 0);
    gapWrap.classList.toggle('negative', gap < 0);

    try {
      localStorage.setItem('turner-budget-draft', JSON.stringify({
        model: $('#budget-model').value,
        target,
        house: valueOf('#budget-house'),
        land: valueOf('#budget-land'),
        foundation: valueOf('#budget-foundation'),
        site: valueOf('#budget-site'),
        options: valueOf('#budget-options'),
        other: valueOf('#budget-other'),
        contingency: contingencyRate
      }));
    } catch (_) {
      // Local persistence is an enhancement; the calculator still works without it.
    }
  }

  function restoreBudgetDraft() {
    try {
      const raw = localStorage.getItem('turner-budget-draft');
      if (!raw) return;
      const draft = JSON.parse(raw);
      const mapping = {
        '#budget-target': draft.target,
        '#budget-house': draft.house,
        '#budget-land': draft.land,
        '#budget-foundation': draft.foundation,
        '#budget-site': draft.site,
        '#budget-options': draft.options,
        '#budget-other': draft.other,
        '#budget-contingency': draft.contingency
      };
      Object.entries(mapping).forEach(([selector, value]) => {
        if (Number.isFinite(Number(value))) $(selector).value = value;
      });
      if (models.some((model) => model.id === draft.model)) $('#budget-model').value = draft.model;
    } catch (_) {
      try { localStorage.removeItem('turner-budget-draft'); } catch (_) {}
    }
  }

  function loadBudgetExample() {
    $('#budget-model').value = 'prague';
    $('#budget-target').value = 575000;
    $('#budget-house').value = 325000;
    $('#budget-land').value = 85000;
    $('#budget-foundation').value = 65000;
    $('#budget-site').value = 28000;
    $('#budget-options').value = 22000;
    $('#budget-other').value = 12000;
    $('#budget-contingency').value = 8;
    updateBudget();
    showToast('Exemple fictif chargé. Remplacez chaque montant par vos données.');
  }

  function budgetSummaryText() {
    const model = models.find((item) => item.id === $('#budget-model').value);
    const subtotal = ['#budget-house', '#budget-land', '#budget-foundation', '#budget-site', '#budget-options', '#budget-other'].reduce((sum, id) => sum + valueOf(id), 0);
    const rate = valueOf('#budget-contingency');
    const contingency = subtotal * rate / 100;
    const total = subtotal + contingency;
    const target = valueOf('#budget-target');
    const gap = target - total;
    return [
      'RÉSUMÉ DE PLANIFICATION — MAISONS S. TURNER',
      `Modèle envisagé : ${model ? model.name : 'À déterminer'}`,
      `Budget cible : ${currency.format(target)}`,
      `Soumission maison : ${currency.format(valueOf('#budget-house'))}`,
      `Terrain : ${currency.format(valueOf('#budget-land'))}`,
      `Excavation et fondation : ${currency.format(valueOf('#budget-foundation'))}`,
      `Raccordements et chantier : ${currency.format(valueOf('#budget-site'))}`,
      `Finitions et options : ${currency.format(valueOf('#budget-options'))}`,
      `Autres frais : ${currency.format(valueOf('#budget-other'))}`,
      `Marge de sécurité (${rate} %) : ${currency.format(contingency)}`,
      `Total simulé : ${currency.format(total)}`,
      `Écart avec le budget : ${currency.format(gap)}`,
      '',
      'Simulation indicative seulement — aucune donnée envoyée, aucun prix officiel.'
    ].join('\n');
  }

  async function copyBudgetSummary() {
    const text = budgetSummaryText();
    try {
      await navigator.clipboard.writeText(text);
      showToast('Résumé copié dans le presse-papiers.');
    } catch (_) {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.append(textarea);
      textarea.select();
      document.execCommand('copy');
      textarea.remove();
      showToast('Résumé copié dans le presse-papiers.');
    }
  }

  function prepareQuote(modelId) {
    const model = models.find((item) => item.id === modelId);
    if (model) {
      $('#contact-model').value = model.id;
      const textarea = $('#contact-form textarea[name="message"]');
      if (!textarea.value.trim()) textarea.value = `Je souhaite discuter du modèle ${model.name} et des adaptations possibles pour mon projet.`;
    }
    $$('#model-dialog, #compare-dialog').forEach((dialog) => {
      if (dialog.open) closeDialog(dialog);
    });
    $('#contact').scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => $('#contact-form input[name="name"]').focus({ preventScroll: true }), 700);
  }

  function setupImageFallbacks() {
    document.addEventListener('error', (event) => {
      const image = event.target;
      if (!(image instanceof HTMLImageElement) || !image.dataset.fallback) return;
      const fallback = image.dataset.fallback;
      image.removeAttribute('data-fallback');
      image.src = fallback;
      const picture = image.closest('picture');
      if (picture) $$('source', picture).forEach((source) => source.remove());
    }, true);
  }

  function setupRevealObserver() {
    const elements = $$('.reveal');
    if (!('IntersectionObserver' in window) || window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      elements.forEach((element) => element.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
    elements.forEach((element) => observer.observe(element));
  }

  function setupHeader() {
    const header = $('[data-header]');
    const update = () => header.classList.toggle('is-scrolled', window.scrollY > 10);
    update();
    window.addEventListener('scroll', update, { passive: true });

    const toggle = $('[data-menu-toggle]');
    const mobileNav = $('[data-mobile-nav]');
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      toggle.setAttribute('aria-label', expanded ? 'Ouvrir le menu' : 'Fermer le menu');
      mobileNav.hidden = expanded;
    });
    $$('a', mobileNav).forEach((link) => link.addEventListener('click', () => {
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Ouvrir le menu');
      mobileNav.hidden = true;
    }));
  }

  function setupEventHandlers() {
    $('#finder-form').addEventListener('submit', (event) => {
      event.preventDefault();
      syncFiltersFromForm();
      $('.catalog-toolbar').scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    $$('#finder-form select').forEach((select) => select.addEventListener('change', syncFiltersFromForm));
    $('#reset-filters').addEventListener('click', () => resetFilters());
    $('#empty-reset').addEventListener('click', () => resetFilters());
    $$('.collection-card').forEach((button) => button.addEventListener('click', () => setCollectionFilter(button.dataset.collection)));

    $('#model-grid').addEventListener('click', (event) => {
      const compare = event.target.closest('[data-compare-id]');
      if (compare) return toggleCompare(compare.dataset.compareId);
      const details = event.target.closest('[data-model-id]');
      if (details) return openModelDialog(details.dataset.modelId);
      const quote = event.target.closest('[data-quote-model]');
      if (quote) return prepareQuote(quote.dataset.quoteModel);
    });

    $('#compare-tray').addEventListener('click', (event) => {
      const remove = event.target.closest('[data-remove-compare]');
      if (remove) toggleCompare(remove.dataset.removeCompare);
    });
    $('#open-compare').addEventListener('click', openCompareDialog);

    $$('.process-tabs button').forEach((button, index) => {
      button.addEventListener('click', () => renderProcessStep(index));
      button.addEventListener('keydown', (event) => {
        if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return;
        event.preventDefault();
        const direction = ['ArrowRight', 'ArrowDown'].includes(event.key) ? 1 : -1;
        const next = (state.currentProcessStep + direction + processSteps.length) % processSteps.length;
        renderProcessStep(next);
        $$('.process-tabs button')[next].focus();
      });
    });

    $('#faq-list').addEventListener('click', (event) => {
      const button = event.target.closest('[data-faq-index]');
      if (button) toggleFaq(Number(button.dataset.faqIndex));
    });

    $$('[data-open-inclusions]').forEach((button) => button.addEventListener('click', () => openDialog($('#inclusions-dialog'))));
    $$('[data-close-dialog]').forEach((button) => button.addEventListener('click', () => closeDialog(button.closest('dialog'))));
    $$('dialog').forEach((dialog) => {
      dialog.addEventListener('click', (event) => { if (event.target === dialog) closeDialog(dialog); });
      dialog.addEventListener('close', () => { if (!$('dialog[open]')) document.body.classList.remove('dialog-open'); });
    });

    $('#model-dialog-content').addEventListener('click', (event) => {
      const quote = event.target.closest('[data-dialog-quote]');
      if (quote) prepareQuote(quote.dataset.dialogQuote);
    });

    $('#budget-form').addEventListener('input', updateBudget);
    $('#budget-form').addEventListener('change', updateBudget);
    $('#budget-form').addEventListener('reset', () => {
      setTimeout(() => {
        $('#budget-contingency').value = 8;
        try { localStorage.removeItem('turner-budget-draft'); } catch (_) {}
        updateBudget();
      }, 0);
    });
    $('#load-example').addEventListener('click', loadBudgetExample);
    $('#copy-summary').addEventListener('click', copyBudgetSummary);

    $('#contact-form').addEventListener('submit', (event) => {
      event.preventDefault();
      const form = event.currentTarget;
      if (!form.reportValidity()) return;
      $('#contact-status').textContent = 'Prototype : votre demande est structurée localement. Aucune donnée n’a été envoyée.';
      showToast('Demande préparée — aucun envoi réel dans ce prototype.');
    });
  }

  function init() {
    $('#current-year').textContent = new Date().getFullYear();
    setupImageFallbacks();
    populateModelSelects();
    restoreBudgetDraft();
    renderModels();
    renderCompareTray();
    renderProcessStep(0);
    renderFaq();
    renderInclusions();
    updateBudget();
    setupHeader();
    setupEventHandlers();
    setupRevealObserver();

    window.TurnerPrototype = {
      models: models.map(({ remoteImage, localImage, ...model }) => model),
      getFilteredModels,
      state
    };
  }

  document.addEventListener('DOMContentLoaded', init);
})();
